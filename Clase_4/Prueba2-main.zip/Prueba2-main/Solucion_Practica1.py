nombre = input("Digite su nombre: ")
apellido = input("Digite sus apellidos: ")
edad = input("Digite su edad: ")
numero = int(input("Digite su número: "))
secreto = 19
if numero == secreto:
  print("Felicitaciones "+nombre+" "+apellido+" el número acertado es: ",numero)
else:
  print("Agradecemos su participación")