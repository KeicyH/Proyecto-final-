print("Buenas")
print("Nochess")