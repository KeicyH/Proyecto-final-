#print palabra reservada
#print("hola mundo")

#input es para solicitar datos
#input("Digite su nombre: ")

#variables el = es de asignación
#nombre = input("Digite su nombre: ")
#print("Hola "+nombre)
edad = 0
nombre = " "
estatura = 0.0
esPar = True

print(edad, nombre, estatura, esPar)
nombre = input("Digite su nombre: ")
# "Jose"
#int()
edad=int(input("Digite su edad: "))

#'29' --> int('29') --> 29
estatura=float(input("Digite su estatura: "))
print(nombre)
print(edad+2)
print(estatura)
print("Digite el nombre: "+nombre+" Su edad es: ",edad)