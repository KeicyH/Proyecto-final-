nombre=(input("Digite su nombre: "))
apellido=(input("Digite su apellido: "))
print("Hola "+nombre+" "+apellido+" que tal tú día")