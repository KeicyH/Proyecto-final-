print("Hola")
print("Buenas noches")