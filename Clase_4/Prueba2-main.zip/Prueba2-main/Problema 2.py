"""Escriba un programa que reciba dos números (Primero uno y
luego el otro), e imprima la suma de los números."""
#Problema 2
num1 = int(input("Digite el primer número: "))
num2 = int(input("Digite el segundo número: "))
suma = num1 + num2
resta = num1 - num2
multi = num1 * num2
division = num1 / num2
modulo = num1 ** num2
elevado = num1^num2
print("El resultado de la suma es de: ",suma)
